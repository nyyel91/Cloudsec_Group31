-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2022 at 05:55 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`) VALUES
(10, 'daniel', '123'),
(12, 'aqeel', '123');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(3, 'Gamers'),
(4, 'Graphic Designers'),
(5, 'IT Workers');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_amount` float NOT NULL,
  `order_transaction` varchar(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `order_currency` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_amount`, `order_transaction`, `order_status`, `order_currency`) VALUES
(37, 89.98, '48438108GF7906821', 'Completed', 'MYR'),
(38, 89.98, '48438108GF7906821', 'Completed', 'MYR'),
(39, 89.98, '48438108GF7906821', 'Completed', 'MYR'),
(40, 24.99, '64G10995JS009551C', 'Completed', 'MYR'),
(41, 24.99, '35E42957KU9009148', 'Completed', 'MYR'),
(42, 5150, '57J837243J3055414', 'Completed', 'MYR'),
(43, 5150, '8718743187761651N', 'Completed', 'MYR'),
(44, 19835, '6NG57652LX132990S', 'Completed', 'MYR'),
(45, 19835, '6NG57652LX132990S', 'Completed', 'MYR'),
(46, 8500, '1M176992X26072013', 'Completed', 'MYR');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_category_id` int(11) NOT NULL,
  `product_price` float NOT NULL,
  `product_qty` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `short_desc` text NOT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_category_id`, `product_price`, `product_qty`, `product_desc`, `short_desc`, `product_image`) VALUES
(21, 'ULTRACORE', 3, 1000, 1, '-3 Years Parts Warranty (Carry-in)\\\\r\\\\n-Lian Li O11D Mini Black\\\\r\\\\n-AMD RYZEN 5 5600X | 4.6 GHZ | 6 Cores 12 Threads\\\\r\\\\n-For AMD - GIGABYTE B550 AORUS ELITE AX v2 1.0\\\\r\\\\n-Zotac GTX 1650 \\r\\n', 'Cheap', 'd4.png'),
(22, 'EXPLORER ', 3, 11075, 5, '-3 Years Parts Warranty (Carry-in)\r\n-Open Loop Water-cooling Hard-line Acrylic Tubing (Select your color)\r\n-AMD RYZEN 7 5800X | 4.7 GHZ | 8 Cores 16 Threads\r\n-For AMD - GIGABYTE X570S AORUS ELITE\r\n-ZOTAC RTX 3070 Twin Edge OC LHR 8GB\r\n-Stock Thermal Compound\r\n-16GB KLEVV BOLT XR 3600mhz ( 2X8GB )\r\n-512GB SAMSUNG PM9A1 M.2 NVME SSD (R: 6900 | W: 5000)\r\n-Standard Cable Setup\r\n-750W Superflower Leadex III 80+ Gold PSU (Fully Modular)\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'OPEN CONCEPT SHOWCASE PC', 'g2.png'),
(23, 'ULTRACORE ', 3, 8760, 5, '-3 Years Parts Warranty (Carry-in)\r\n-Lian Li O11D EVO (Black)\r\n-AMD RYZEN 7 5800X | 4.7 GHZ | 8 Cores 16 Threads\r\n-For AMD - GIGABYTE X570S AORUS ELITE\r\n-ZOTAC RTX 3070 Twin Edge OC LHR 8GB\r\n-Stock Thermal Compound\r\n-16GB KLEVV BOLT XR 3600mhz ( 2X8GB )\r\n-WATERCOOLING : AFTERSHOCK Spectra Glacier Mirror 240mm\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-Standard Chassis Fans\r\n-Standard Cable Setup\r\n-800W FSP HYDRO PRO 80+ Bronze Certified PSU\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'THE ULTIMATE CUSTOM PC', 'g3.png'),
(24, 'TRIXEL ', 3, 5850, 5, '-3 Years Parts Warranty (Carry-in)\r\n-Trixel Chassis (INWIN 309)\r\n-AMD RYZEN 7 5800X | 4.7 GHZ | 8 Cores 16 Threads\r\n-For AMD - GIGABYTE B550 AORUS ELITE AX v2 1.0\r\n-Zotac GTX 1650 OC 4GB\r\n-Stock Thermal Compound\r\n-8GB KLEVV Performance 3200 Mhz (8x1)\r\n-AIR COOLING : Intel / AMD stock cooling fan\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-Standard Cable Setup\r\n-800W FSP HYDRO PRO 80+ Bronze Certified PSU\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'RGB OVERLOAD', 'g4.png'),
(25, 'TEMPLAR ', 3, 8500, 5, '-3 Years Parts Warranty (Carry-in)\r\n-NZXT H510i White Chassis (Includes NZXT Advanced ARGB)\r\n-AMD RYZEN 7 5800X | 4.7 GHZ | 8 Cores 16 Threads\r\n-For Intel - ASROCK B560 PRO 4\r\n-ZOTAC RTX 3060 Twin Edge OC White (LHR) 12GB\r\n-Stock Thermal Compound\r\n-8GB KLEVV Performance 3200 Mhz (8x1)\r\n-AIR COOLING : Intel / AMD stock cooling fan\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-ID COOLING DF-12025 White ARGB Fans\r\n-Horizontal GPU Mounting (HYPERGATE)\r\n-Standard Cable Setup\r\n-800W FSP HYDRO PRO 80+ Bronze Certified PSU\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'WHITE EDITION PC', 'g5.png'),
(26, 'ZEAL ', 4, 4110, 5, '-3 Years Parts Warranty (Carry-in)\r\n-ZEAL Tempered Glass Showcase Edition\r\n-AMD RYZEN 5 3600 | 4.2 GHZ | 6 Cores 12 Threads\r\n-For AMD - GIGABYTE B550 AORUS ELITE AX v2 1.0\r\n-Zotac GTX 1650 OC 4GB\r\n-Stock Thermal Compound\r\n-8GB KLEVV Performance 3200 Mhz (8x1)\r\n-AIR COOLING : Intel / AMD stock cooling fan\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-Standard Chassis Fans\r\n-Standard Cable Setup\r\n-800W FSP HYDRO PRO 80+ Bronze Certified PSU\r\n-Standard GPU Mounting (Default Horizontal Option for Standard And Showcase Edition Chassis)\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'EXTREME MID TOWER PC', 'd1.png'),
(27, 'HYPERGATE ', 4, 4200, 5, '-3 Years Parts Warranty (Carry-in)\r\n-NZXT H510i Minimalist Stealth Black Chassis (Includes NZXT advanced RGB and NZXT Cam by default)\r\n-AMD RYZEN 5 3600 | 4.2 GHZ | 6 Cores 12 Threads\r\n-For AMD - GIGABYTE B550 AORUS ELITE AX v2 1.0\r\n-Zotac GTX 1650 OC 4GB\r\n-Stock Thermal Compound\r\n-8GB KLEVV Performance 3200 Mhz (8x1)\r\n-AIR COOLING : Intel / AMD stock cooling fan\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-NZXT Advanced RGB Case Lights (Multicolor | Software configurable)\r\n-NZXT Aer F120mm fans x 2\r\n-Horizontal GPU Mounting (HYPERGATE)\r\n-Standard Cable Setup\r\n-800W FSP HYDRO PRO 80+ Bronze Certified PSU\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'BUILT WITH NZXT DESIGN', 'd2.png'),
(28, 'SHADOW ', 4, 4400, 5, '-3 Years Parts Warranty (Carry-in)\\r\\n-BEQUIET PURE BASE 500DX (High Airflow Low Noise Chassis) (BLACK)\\r\\n-AMD RYZEN 5 3600 | 4.2 GHZ | 6 Cores 12 Threads\\r\\n-For AMD - GIGABYTE B550 AORUS ELITE AX v2 1.0\\r\\n-Zotac GTX 1650 OC 4GB\\r\\n-Stock Thermal Compound\\r\\n-8GB KLEVV Performance 3200 Mhz (8x1)\\r\\n-AIR COOLING : Intel / AMD stock cooling fan\\r\\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\\r\\n-1TB TOSHIBA 7200RPM HDD\\r\\n-BEQUIET Pure Wings 140mm (Stealth Fans, Silent) X 3\\r\\n-Standard Cable Setup\\r\\n-800W FSP HYDRO PRO 80+ Bronze Certified PSU\\r\\n-Windows 10 Home 64bit ***(Unactivated)***', 'BEQUIET GERMAN DESIGN', 'd3.png'),
(29, 'HYPERGATE ELITE ', 4, 4350, 5, '-3 Years Parts Warranty (Carry-in)\r\n-NZXT H510 ELITE: White\r\n-AMD RYZEN 5 3600 | 4.2 GHZ | 6 Cores 12 Threads\r\n-For AMD - GIGABYTE B550 AORUS ELITE AX v2 1.0\r\n-Zotac GTX 1650 OC 4GB\r\n-Stock Thermal Compound\r\n-8GB KLEVV Performance 3200 Mhz (8x1)\r\n-AIR COOLING : Intel / AMD stock cooling fan\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-NZXT Advanced RGB Case Lights (Multicolor | Software configurable)\r\n-NZXT AER2 RGB X 2 + NZXT Standard Fans X 2 (H510 Elite Chassis Default)\r\n-Horizontal GPU Mounting (HYPERGATE)\r\n-Standard Cable Setup\r\n-800W FSP HYDRO PRO 80+ Bronze Certified PSU\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'BUILT WITH NZXT DESIGN', 'd4.png'),
(30, 'RAPID ', 4, 3660, 5, '-3 Years Parts Warranty (Carry-in)\r\n-RAPID Black Mesh High Airflow Tempered Glass Chassis\r\n-Intel® Core™ i5-12400F | 4.4 GHZ | 6 Cores 12 Threads\r\n-For Intel - GIGABYTE B660M DS3H\r\n-Zotac GTX 1650 OC 4GB\r\n-Stock Thermal Compound\r\n-8GB KLEVV Performance 3200 Mhz (8x1)\r\n-AIR COOLING : Intel / AMD stock cooling fan\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-LEVEL51 S1 ARGB Fans X 4\r\n-Standard Cable Setup\r\n-800W FSP HYDRO PRO 80+ Bronze Certified PSU\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'ULTIMATE VALUE', 'd5.png'),
(31, 'VAULT MESH ', 5, 5625, 5, '-3 Years Parts Warranty (Carry-in)\r\n-VAULT MESH Black\r\n-Vault Mesh standard mesh\r\n-AMD RYZEN 7 5800X | 4.7 GHZ | 8 Cores 16 Threads\r\n-For AMD - GIGABYTE B550i AORUS PRO AX (Includes AX Wifi)\r\n-Zotac GTX 1650 OC 4GB\r\n-Stock Thermal Compound\r\n-8GB KLEVV Performance 3200 Mhz (8x1)\r\n-AIR COOLING : Intel / AMD stock cooling fan\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-Standard Fans X 2\r\n-650W FSP DAGGER PRO 80+ GOLD Certified Modular PSU (For Horizon ITX)\r\n-Wifi+Bluetooth Included (Version Depends on the motherboard you select)\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'COMPACT MESH PC', 'i1.png'),
(32, 'VAULT ', 5, 5185, 5, '-3 Years Parts Warranty (Carry-in)\r\n-NZXT H1 Black\r\n-Vault Mesh standard mesh\r\n-AMD RYZEN 5 5600X | 4.6 GHZ | 6 Cores 12 Threads\r\n-For AMD - ASROCK B550M ITX/AC (Includes AC Wifi)\r\n-Zotac GTX 1650 OC 4GB\r\n-Stock Thermal Compound\r\n-8GB KLEVV Performance 3200 Mhz (8x1)\r\n-NZXT 140MM AIO Watercooling (H1)\r\n-512GB Samsung NVME M.2 SSD (R 3500 | W 2900)\r\n-650W 80+ Gold Certified Premium PSU (Included with NZXT H1)\r\n-Wifi+Bluetooth Included (Version Depends on the motherboard you select)\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'COMPACT EXTREME PC', 'i2.png'),
(33, 'FOCUS X ', 5, 13840, 5, '-3 Years Parts Warranty (Carry-in)\r\n-Bequiet Dark Base 900 Silent Workstation Chassis\r\n-AMD ThreadRipper 3960X (24 Cores | 48 Threads, up to 4.5 Ghz)(Recommended)\r\n-For AMD - ASROCK TRX40 CREATOR Motherboard (Required for 3000 Series Threadripper CPUs)\r\n-GTX 1660 SUPER 6GB GDDR6\r\n-16GB DDR4 2666 Mhz ( 2X8GB | Dual Channel )\r\n-Stock Thermal Compound\r\n-AIR COOLING : Bequiet Dark Rock Pro 4 (Ultra Silent, Best In Class Air Cooling)\r\n-1TB SAMSUNG PM9A1 M.2 NVME SSD (R: 6900 | W: 5000)\r\n-1200W SUPERFLOWER LEADEX PLATINUM SE PSU (Fully Modular, 1-2 GPU configurations)\r\n-BEQUIET SILENT WINGS 3 140mm PWM (Stealth Fans, Ultra Silent, 300000 hours lifespan) (FOCUS X) X 3\r\n-Windows 10 Home 64bit ***(Unactivated)***', 'OFFCE/HOME HEAVY PRODUCTIVITY', 'i3.png'),
(36, 'Razer', 3, 3000, 3, 'Razer good', 'Nice', 'i2.png');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_price` float NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`report_id`, `product_id`, `order_id`, `product_price`, `product_title`, `product_qty`) VALUES
(32, 21, 42, 5150, 'ULTRACORE MINI ', 1),
(33, 21, 43, 5150, 'ULTRACORE MINI ', 1),
(34, 22, 44, 11075, 'EXPLORER ', 1),
(35, 23, 45, 8760, 'ULTRACORE ', 1),
(36, 25, 46, 8500, 'TEMPLAR ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(225) NOT NULL,
  `email_user` varchar(255) NOT NULL,
  `address_user` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
