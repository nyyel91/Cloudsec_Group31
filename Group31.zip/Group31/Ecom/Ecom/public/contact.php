
<!-- Configuration-->

<?php require_once("../resources/config.php"); ?>


<!-- Header-->
<!--Navigation -->
<?php include(TEMPLATE_FRONT .  "/header.php");?>



         <!-- Contact Section -->

        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="section-heading" style="color:magenta;">Contact Us</h2>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form name="sentMessage" id="contactForm" method="post" >
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <p>Instagram</p>
                                   <a href="https://www.instagram.com/?hl=en">Visit us at Instagram</a>
                                </div>
                                <div class="form-group">
                                    <p>Twitter</p>
                                    <a href="https://twitter.com/?lang=en">Visit us at Twitter</a>
                                </div>
                                <div class="form-group">
                                    <p>Email</p>
                                         <a href="https://accounts.google.com/b/1/AddMailService">Email Us</a>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container -->
<?php include(TEMPLATE_FRONT .  "/footer.php");?>
