<?php  require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT .DS. "header.php"); ?>
<?php add_user(); ?>
<!-- This add user for users-->
  <h1 class="page-header">
      Add User
  </h1>


<form action="" method="post" enctype="multipart/form-data">
  <div class="col-md-6">

     <div class="form-group">
      <label for="username">Username</label>
      <input type="text" name="username" class="form-control" >

     </div>

      <div class="form-group">
          <label for="password">Password</label>
      <input type="password" name="password" class="form-control"  >

     </div>
      
       <div class="form-group">
          <label for="password">Email</label>
      <input type="email" name="email_user" class="form-control"  >

     </div>
      
       <div class="form-group">
          <label for="password">Address</label>
      <input type="Address" name="address_user" class="form-control"  >

     </div>

      <div class="form-group">
      <input type="submit" name="add_user" class="btn btn-primary pull-left" value="Add User" >

     </div>


  </div>



</form>
