<?php  require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT .DS. "header.php"); ?>

    <!-- Page Content -->
    <div class="container">


<!-- /.row -->

<div class="row">
      <h4 class="text-center bg-danger"><?php display_message(); ?> </h4>
      <h1 style="color:magenta;">Checkout</h1>

<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="get">
      <input type="hidden" name="cmd" value="_cart">
      <input type="hidden" name="business" value="sb-00hyn14645797@business.example.com">
      <input type="hidden" name="currency_code" value="MYR">
      <input type="hidden" name="upload" value="1">
    <table class="table table-striped">
        <thead>
          <tr>
           <th style="color:white;">Product</th>
           <th style="color:white;">Price</th>
           <th style="color:white;">Quantity</th>
           <th style="color:white;">Sub-total</th>

          </tr>
        </thead>
        <tbody>
            <?php cart(); ?>
        </tbody>
    </table>
<?php echo show_paypal(); ?>
</form>

<!--  ***********CART TOTALS*************-->

<div class="col-xs-4 pull-right ">
<h2 style="color:white;">Cart Totals</h2>

<table class="table table-bordered" cellspacing="0">

<tr class="cart-subtotal">
<th style="color:white;">Items:</th>
<td style="color:white;"><span class="amount"><?php echo isset($_SESSION['item_qty']) ?$_SESSION['item_qty']:$_SESSION['item_qty']="0" ;//if got value show value if not empty string ?></span></td>
</tr>
<tr class="shipping">
<th style="color:white;">Shipping and Handling</th>
<td style="color:white;">Free Shipping</td>
</tr>

<tr class="order-total">
<th style="color:white;">Order Total</th>
<td style="color:white;"><strong><span class="amount">RM
  <?php echo isset($_SESSION['item_total']) ?$_SESSION['item_total']:$_SESSION['item_total']="0" ;//if got value show value if not empty string ?>
</span></strong> </td>
</tr>


</tbody>

</table>

</div><!-- CART TOTALS-->


 </div><!--Main Content-->


    </div>
    <!-- /.container -->
<?php include(TEMPLATE_FRONT .DS. "footer.php"); ?>
