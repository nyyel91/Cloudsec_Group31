<?php require_once("../../resources/config.php") ?>
<?php include(TEMPLATE_USERS . "/header.php"); ?>
<?php

if(!isset($_SESSION['username'])){
  //to prevent unkown user to log in
  redirect("../../public");
}
 ?>
        <div id="page-wrapper">

            <div class="container-fluid">
                <!-- /.row -->
            <?php
//from index go to other page
            if($_SERVER['REQUEST_URI'] == "/Ecom/public/customer/" || $_SERVER['REQUEST_URI'] == "/Ecom/public/customer/index.php") {
                include(TEMPLATE_USERS . "/user_content.php");
            }
            if(isset($_GET['users'])){
                  include(TEMPLATE_USERS . "/users.php");
            }
            if(isset($_GET['edit_user'])){
                  include(TEMPLATE_USERS . "/edit_user.php");
            }

             ?>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
        <?php include(TEMPLATE_USERS . "/footer.php"); ?>
