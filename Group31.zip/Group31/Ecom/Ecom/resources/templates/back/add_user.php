<?php add_admin(); ?>
<!-- This add user for admin-->
  <h1 class="page-header">
      Add Admin
  </h1>


<form action="" method="post" enctype="multipart/form-data">
  <div class="col-md-6">

     <div class="form-group">
      <label for="username">Username</label>
      <input type="text" name="username" class="form-control" >

     </div>

      <div class="form-group">
          <label for="password">Password</label>
      <input type="password" name="password" class="form-control"  >
          
          

     </div>

      <div class="form-group">
      <input type="submit" name="add_admin" class="btn btn-primary pull-left" value="Add User" >

     </div>


  </div>



</form>
