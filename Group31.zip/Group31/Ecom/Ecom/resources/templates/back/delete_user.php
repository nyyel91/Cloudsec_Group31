<?php require_once("../../config.php");

//This add user for admin
if(isset($_GET['id'])){
//take id and delete from database
$query=query("DELETE FROM admin WHERE admin_id =".escape_string($_GET['id'])." ");
confirm($query);

set_message("Admin Infomation Deleted");
redirect("../../../public/admin/index.php?users");
}else{
redirect("../../../public/admin/index.php?users");
}
 ?>
