
<!-- This add user for admin-->

        <div id="page-wrapper">

            <div class="container-fluid">



                    <div class="col-lg-12">


                        <h1 class="page-header">
                            Admin
                        </h1>
                        <h3 class="bg-success"><?php display_message(); ?></h3>


                        <a href="index.php?add_user" class="btn btn-primary">Add Another Admin</a>


                        <div class="col-md-12">

                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Username</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                      <?php display_admin(); ?>
                                    </tr>


                                </tbody>
                            </table> <!--End of Table-->


                        </div>











                    </div>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
