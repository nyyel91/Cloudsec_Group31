<?php require_once("../../config.php");


if(isset($_GET['id'])){
//take id and delete from database
$query=query("DELETE FROM categories WHERE cat_id =".escape_string($_GET['id'])." ");
confirm($query);

set_message("Categories Deleted");
redirect("../../../public/admin/index.php?categories");
}else{
redirect("../../../public/admin/index.php?categories");
}
 ?>
