

<?php

//check got product or not
if(isset($_GET['id'])){

$query=query("SELECT * FROM users WHERE user_id = " . escape_string($_GET['id']). " ");
confirm($query);

while($row=fetch_array($query)){
  $username = escape_string($row['username']);
  $password = escape_string($row['password']);
    $email_user = escape_string($row['email_user']);
  $address_user = escape_string($row['address_user']);

  
}
update_user();

}
 ?>
        <div id="page-wrapper">

            <div class="container-fluid">
<div class="col-md-12">

<div class="row">
<h1 class="page-header">
   Edit users
</h1>
</div>


<!--enctype use to upload image-->
<form action="" method="post" enctype="multipart/form-data">

<div class="col-md-8">

<div class="form-group">
    <label for="product-title">Username </label>
        <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">

    </div>


    <div class="form-group">
           <label for="product-title">Password</label>
      <textarea name="password" id="" cols="30" rows="10" class="form-control" ><?php echo $password; ?></textarea>
    </div>


      <div class="form-group">
           <label for="product-title">Email</label>
      <textarea name="email_user" id="" cols="30" rows="10" class="form-control" ><?php echo $email_user; ?></textarea>
    </div>
    
      <div class="form-group">
           <label for="product-title">Address</label>
      <textarea name="address_user" id="" cols="30" rows="10" class="form-control" ><?php echo $address_user; ?></textarea>
    </div>
    

  <div class="form-group">
        <input type="submit" name="update" class="btn btn-primary btn-lg" value="Update">
    </div>







</div><!--Main Content-->


<!-- SIDEBAR-->












            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
