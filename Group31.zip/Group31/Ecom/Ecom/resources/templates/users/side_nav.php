<div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav">
        <li class="active">
            <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
        </li>
        <li class="">
            <a href="index.php?users"><i class="fa fa-fw fa-dashboard"></i> VIew Personal Data</a>
        </li>
          <li class="">
            <a href="log_out.php"><i class="fa fa-fw fa-sign-out"></i> Log Out</a>
        </li>

    </ul>
</div>
