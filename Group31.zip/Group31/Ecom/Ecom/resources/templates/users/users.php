
<!-- This add user for admin-->

        <div id="page-wrapper">

            <div class="container-fluid">



                    <div class="col-lg-12">


                        <h1 class="page-header">
                            User
                        </h1>
                        <h3 class="bg-success"><?php display_message(); ?></h3>


                        <div class="col-md-12">

                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Address</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                      <?php display_user(); ?>
                                        <?php
                                        
                                        

                                //check got product or not
                               
                                 ?>
                                    </tr>

                                   
                                       
  
                                        
                                        
                                </tbody>
                            </table> <!--End of Table-->


                        </div>
                        
                       











                    </div>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
