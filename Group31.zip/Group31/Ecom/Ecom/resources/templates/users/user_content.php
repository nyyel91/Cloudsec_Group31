
<head>
<title>User Dashboard</title>
<link rel="stylesheet" href="dashboardadmin.css">
</head>

<div class="container">
    <span class="text1">Welcome <?php
    if(isset($_SESSION['username']) ){
               echo $_SESSION['username'];

            } else {

                echo "unregistered User";
            }
 ?></span>
    <span class="text2">to admin dashboard page</span>
</div>
