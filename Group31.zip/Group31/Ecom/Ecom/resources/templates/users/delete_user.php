<?php require_once("../../config.php");

//This add user for admin
if(isset($_GET['id'])){
//take id and delete from database
$query=query("DELETE FROM users WHERE user_id =".escape_string($_GET['id'])." ");
confirm($query);

set_message("User Infomation Deleted");
redirect("../../../public/customer/index.php?users");
}else{
redirect("../../../public/customer/index.php?users");
}
 ?>